from Abstractions.Products import Products
from Models.ProductModel import ProductModel
from Models.VendorSessionModel import VendorSessionModel


class ProductsImplementation(Products):

    def __init__(self, username):
        self.product_model = ProductModel()
        self.vendor_session = VendorSessionModel()
        self._username = username

    def add_product(self, product_name, product_type, available_quantity, unit_price):
        if not self.vendor_session.check_login(self._username):
            print("Kindly login and add the product")
            return False
        
        self.product_model.add_product(product_name,product_type,available_quantity,unit_price)
        print(product_name+"added successfully")
        return True
            
    def search_product_by_name(self, product_name):
        if not self.vendor_session.check_login(self._username):
            print("kindly login and add products later search the product")
            return False

        searched_prod=self.product_model.search_product(product_name)
        print(product_name+"found in database")
        return searched_prod

    def get_all_products(self):
        if not self.vendor_session.check_login(self._username):
            print("kindly login to find the products")
            return False
        
        self.product_model.all_products()
        return True